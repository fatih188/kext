//
//  MtkWlanUserClient.cpp
//  SimpleMtkWlan
//
//  Created by laobamac (王孝慈) on 2026/3/12.
//  Copyright © 2026 laobamac (王孝慈). All rights reserved.
//

/*
* Copyright (C) 2020  钟先耀
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

#include "MtkWlanUserClient.hpp"
#include <sys/_netstat.h>

#define super IOUserClient
OSDefineMetaClassAndStructors( MtkWlanUserClient, IOUserClient );

static constexpr int kMtkMinDbm = -100;

const IOControlMethodAction MtkWlanUserClient::sMethods[IOCTL_ID_MAX] {
    sDRIVER_INFO,
    sSTA_INFO,
    sPOWER,
    sSTATE,
    sNW_ID,
    sWPA_KEY,
    sASSOCIATE,
    sDISASSOCIATE,
    sJOIN,
    sSCAN,
    sSCAN_RESULT,
    sTX_POWER_LEVEL,
    sNW_BSSID,
    sDEBUG,
    sLOG,
};

bool MtkWlanUserClient::initWithTask(task_t owningTask, void *securityID, UInt32 type, OSDictionary *properties)
{
    fTask = owningTask;
    return super::initWithTask(owningTask, securityID, type, properties);
}

bool MtkWlanUserClient::start(IOService *provider)
{
//    IOLog("start\n");
    if( !super::start( provider ))
        return false;
    fDriver = OSDynamicCast(MtkUserClientProvider, provider);
    if (fDriver == NULL || fDriver->fHalService == NULL) {
        return false;
    }
#ifdef AIRPORT
    fIfp = &fDriver->fHalService->get80211Controller()->ic_ac.ac_if;
    fInf = fIfp->iface;
#else
    fInf = fDriver->getNetworkInterface();
    fIfp = fDriver->getIfp();
#endif
    fDriverInfo = fDriver->fHalService->getDriverInfo();
    fDriverController = fDriver->fHalService->getDriverController();
    return true;
}

IOReturn MtkWlanUserClient::clientClose()
{
//    IOLog("clientClose\n");
    if( !isInactive())
        terminate();
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::clientDied()
{
//    IOLog("clientDied\n");
    return super::clientDied();
}

void MtkWlanUserClient::stop(IOService *provider)
{
//    IOLog("stop\n");
    super::stop( provider );
}

IOReturn MtkWlanUserClient::externalMethod(uint32_t selector, IOExternalMethodArguments * arguments, IOExternalMethodDispatch * dispatch, OSObject * target, void * reference)
{
    bool isSet = selector & IOCTL_MASK;
    selector &= ~IOCTL_MASK;
//    IOLog("externalMethod invoke. selector=0x%X isSet=%d\n", selector, isSet);
    if (selector >= IOCTL_ID_MAX) {
        return super::externalMethod(selector, arguments, NULL, this, NULL);
    }
    void *data = isSet ? (void *)arguments->structureInput : (void *)arguments->structureOutput;
    if (!data) {
        return kIOReturnError;
    }
    if (!isSet && selector == IOCTL_80211_DEBUG &&
        arguments->structureOutputSize < sizeof(struct ioctl_debug))
        return kIOReturnBadArgument;
    if (isSet && selector == IOCTL_80211_DEBUG &&
        arguments->structureInputSize < sizeof(struct ioctl_debug_set))
        return kIOReturnBadArgument;
    if (!isSet && selector == IOCTL_80211_LOG &&
        arguments->structureOutputSize < sizeof(struct ioctl_log))
        return kIOReturnBadArgument;
    return sMethods[selector](this, data, isSet);
}

IOReturn MtkWlanUserClient::
sDRIVER_INFO(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    ioctl_driver_info *drv_info = (ioctl_driver_info *)data;
    memset(drv_info, 0, sizeof(*drv_info));
    drv_info->version = IOCTL_VERSION;
    if (that->fInf && that->fInf->getIfnet())
        snprintf(drv_info->bsd_name, sizeof(drv_info->bsd_name), "%s%d", ifnet_name(that->fInf->getIfnet()), ifnet_unit(that->fInf->getIfnet()));
    strncpy(drv_info->fw_version, that->fDriverInfo->getFirmwareVersion(), sizeof(drv_info->fw_version));
    snprintf(drv_info->driver_version, sizeof(drv_info->driver_version), "%s%s", SMTW_VERSION, GIT_COMMIT);
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sSTA_INFO(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_sta_info *st = (struct ioctl_sta_info *)data;
    struct ieee80211com *ic = that->fDriver->fHalService->get80211Controller();
    struct ieee80211_node *ic_bss = ic->ic_bss;
    int nss;
    int sgi;
    int index = 0;
    if (isSet) {
        return kIOReturnError;
    }
    if (ic_bss == NULL) {
        return kIOReturnError;
    }
    if (ic_bss->ni_chan == NULL) {
        return kIOReturnError;
    }
    if (ic->ic_state != IEEE80211_S_RUN) {
        return kIOReturnError;
    }
    st->version = IOCTL_VERSION;
    st->op_mode = ic->ic_curmode > 0 ? (enum mtk_phy_mode)(ic->ic_curmode - 1) : MTK80211_MODE_11A;
    st->max_mcs = ic_bss->ni_txmcs;
    st->cur_mcs = ic_bss->ni_txmcs;
    st->channel = ieee80211_chan2ieee(ic, ic_bss->ni_chan);
    switch (ic->ic_bss->ni_chw) {
        case IEEE80211_CHAN_WIDTH_40:
            st->band_width = 40;
            break;
        case IEEE80211_CHAN_WIDTH_80:
            st->band_width = 80;
            break;
        case IEEE80211_CHAN_WIDTH_80P80:
        case IEEE80211_CHAN_WIDTH_160:
            st->band_width = 160;
            break;
            
        default:
            st->band_width = 20;
            break;
    }
    st->rssi = -(0 - kMtkMinDbm - ic_bss->ni_rssi);
    st->noise = that->fDriver->fHalService->getDriverInfo()->getBSSNoise();
    sgi = ieee80211_node_supports_sgi(ic_bss);
    if (ic->ic_curmode == IEEE80211_MODE_11AC) {
        if (sgi) {
            index += 1;
        }
        nss = that->fDriverInfo->getTxNSS();
        switch (ic_bss->ni_chw) {
            case IEEE80211_CHAN_WIDTH_40:
                index += 4;
                break;
            case IEEE80211_CHAN_WIDTH_80:
                index += 8;
                break;
            case IEEE80211_CHAN_WIDTH_80P80:
            case IEEE80211_CHAN_WIDTH_160:
                index += 12;
                break;

            default:
                break;
        }
        index += 2 * (nss - 1);
        const struct ieee80211_vht_rateset *rs = &ieee80211_std_ratesets_11ac[index];
        st->rate = rs->rates[ic_bss->ni_txmcs % rs->nrates] / 2;
    } else if (ic->ic_curmode == IEEE80211_MODE_11AX) {
        nss = ic_bss->ni_vht_ss > 1 ? 2 : 1;
        switch (ic_bss->ni_chw) {
            case IEEE80211_CHAN_WIDTH_40:
                index = IEEE80211_HE_RATESET_SISO_40;
                break;
            case IEEE80211_CHAN_WIDTH_80:
                index = IEEE80211_HE_RATESET_SISO_80;
                break;
            case IEEE80211_CHAN_WIDTH_80P80:
            case IEEE80211_CHAN_WIDTH_160:
                index = IEEE80211_HE_RATESET_SISO_160;
                break;

            default:
                index = IEEE80211_HE_RATESET_SISO;
                break;
        }
        index += nss - 1;
        const struct ieee80211_he_rateset *rs = &ieee80211_std_ratesets_11ax[index];
        st->rate = rs->rates[ic_bss->ni_txmcs % rs->nrates] / 2;
    } else if (ic->ic_curmode == IEEE80211_MODE_11N) {
        int is_40mhz = ic_bss->ni_chw == IEEE80211_CHAN_WIDTH_40;
        if (sgi) {
            index += 1;
        }
        if (is_40mhz) {
            index += (IEEE80211_HT_RATESET_MIMO4_SGI + 1);
        }
        index += (ic_bss->ni_txmcs / 16);
        nss = ic_bss->ni_txmcs / 8 + 1;
        index += 2 * (nss - 1);
        st->rate = ieee80211_std_ratesets_11n[index].rates[ic_bss->ni_txmcs % 8] / 2;
    } else {
        st->rate = ic_bss->ni_rates.rs_rates[ic_bss->ni_txrate];
    }
    memset(st->ssid, 0, sizeof(st->ssid));
    bcopy(ic->ic_des_essid, st->ssid, ic->ic_des_esslen);
    memset(st->bssid, 0, sizeof(st->bssid));
    bcopy(ic->ic_bss->ni_bssid, st->bssid, ETHER_ADDR_LEN);
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sPOWER(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_power *ip = (struct ioctl_power *)data;
    if (isSet) {
#ifdef AIRPORT
        return kIOReturnUnsupported;
#else
        if (ip->enabled) {
            that->fDriver->enable(that->fInf);
        } else {
            net80211_ifstats(that->fDriver->fHalService->get80211Controller());
            that->fDriver->disable(that->fInf);
        }
#endif
    } else {
        memset(ip, 0, sizeof(*ip));
        ip->version = IOCTL_VERSION;
        ip->enabled = (that->fIfp->if_flags & (IFF_UP | IFF_RUNNING)) != 0;
    }
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sSTATE(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_state *st = (struct ioctl_state *)data;
    if (isSet) {
        return kIOReturnError;
    }
    memset(st, 0, sizeof(*st));
    st->version = IOCTL_VERSION;
    st->state = (mtk_80211_state)that->fDriver->fHalService->get80211Controller()->ic_state;
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sNW_BSSID(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_nw_bssid *nwid = (struct ioctl_nw_bssid *)data;
    struct ieee80211com *ic = that->fDriver->fHalService->get80211Controller();
    
    if (isSet) {
        if (IEEE80211_ADDR_EQ(nwid->bssid, etheranyaddr))
            ic->ic_flags &= ~IEEE80211_F_DESBSSID;
        else {
            ic->ic_flags |= IEEE80211_F_DESBSSID;
            IEEE80211_ADDR_COPY(ic->ic_des_bssid, nwid->bssid);
        }
        return kIOReturnSuccess;
    }
    memset(nwid, 0, sizeof(*nwid));
    nwid->version = IOCTL_VERSION;
    switch (ic->ic_state) {
        case IEEE80211_S_INIT:
        case IEEE80211_S_SCAN:
#ifndef IEEE80211_STA_ONLY
            if (ic->ic_opmode == IEEE80211_M_HOSTAP)
                IEEE80211_ADDR_COPY(nwid->bssid,
                                    ic->ic_myaddr);
            else
#endif
                if (ic->ic_flags & IEEE80211_F_DESBSSID)
                    IEEE80211_ADDR_COPY(nwid->bssid,
                                        ic->ic_des_bssid);
                else
                    memset(nwid->bssid, 0, IEEE80211_ADDR_LEN);
            break;
        default:
            IEEE80211_ADDR_COPY(nwid->bssid,
                                ic->ic_bss->ni_bssid);
            break;
    }
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sNW_ID(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_nw_id *nwid = (struct ioctl_nw_id *)data;
    struct ieee80211com *ic = that->fDriver->fHalService->get80211Controller();
    
    if (isSet) {
        if (nwid->len > IEEE80211_NWID_LEN) {
            return kIOReturnError;
        }
        memset(ic->ic_des_essid, 0, IEEE80211_NWID_LEN);
        ic->ic_des_esslen = nwid->len;
        memcpy(ic->ic_des_essid, nwid->nwid, nwid->len);
        if (ic->ic_des_esslen > 0) {
            /* 'nwid' disables auto-join magic */
            ic->ic_flags &= ~IEEE80211_F_AUTO_JOIN;
        } else if (!TAILQ_EMPTY(&ic->ic_ess)) {
            /* '-nwid' re-enables auto-join */
            ic->ic_flags |= IEEE80211_F_AUTO_JOIN;
        }
        /* disable WPA/WEP */
        ieee80211_disable_rsn(ic);
        ieee80211_disable_wep(ic);
        return kIOReturnSuccess;
    }
    memset(nwid, 0, sizeof(*nwid));
    nwid->version = IOCTL_VERSION;
    switch (ic->ic_state) {
    case IEEE80211_S_INIT:
    case IEEE80211_S_SCAN:
        nwid->len = ic->ic_des_esslen;
        memcpy(nwid->nwid, ic->ic_des_essid, nwid->len);
        break;
    default:
        nwid->len = ic->ic_bss->ni_esslen;
        memcpy(nwid->nwid, ic->ic_bss->ni_essid, nwid->len);
        break;
    }
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sWPA_KEY(OSObject* target, void* data, bool isSet)
{
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sASSOCIATE(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_associate *as = (struct ioctl_associate *)data;
#ifdef AIRPORT
    return kIOReturnUnsupported;
#else
    that->fDriver->associateSSID(as->nwid.nwid, as->wpa_key.key);
#endif
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sDISASSOCIATE(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_disassociate *dis = (struct ioctl_disassociate *)data;
    struct ieee80211com *ic = that->fDriver->fHalService->get80211Controller();
    if (ic->ic_state > IEEE80211_S_AUTH && ic->ic_bss != NULL)
        IEEE80211_SEND_MGMT(ic, ic->ic_bss, IEEE80211_FC0_SUBTYPE_DEAUTH, IEEE80211_REASON_AUTH_LEAVE);
    ieee80211_del_ess(ic, (char *)dis->ssid, strlen((char *)dis->ssid), 0);
    ieee80211_deselect_ess(ic);
    if (TAILQ_EMPTY(&ic->ic_ess)) {
        ic->ic_flags |= IEEE80211_F_AUTO_JOIN;
    }
    ieee80211_new_state(ic, IEEE80211_S_SCAN, -1);
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sJOIN(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_join *join = (struct ioctl_join *)data;
#ifdef AIRPORT
    return kIOReturnUnsupported;
#else
    that->fDriver->joinSSID(join->nwid.nwid, join->wpa_key.key);
#endif
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sSCAN(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    ieee80211_begin_cache_bgscan(that->fIfp);
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sSCAN_RESULT(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_network_info *ni = (struct ioctl_network_info *)data;
    ieee80211com *ic = that->fDriver->fHalService->get80211Controller();
    if (that->fNextNodeToSend == NULL) {
        if (that->fScanResultWrapping) {
            that->fScanResultWrapping = false;
            return kIONoScanResult;
        } else {
            that->fNextNodeToSend = RB_MIN(ieee80211_tree, &ic->ic_tree);
            if (that->fNextNodeToSend == NULL) {
                return kIONoScanResult;
            }
        }
    }
    bzero(ni, sizeof(*ni));
    
    ni->ni_rsncaps = that->fNextNodeToSend->ni_capinfo;;
    ni->channel = ieee80211_chan2ieee(ic, that->fNextNodeToSend->ni_chan);
    ni->ni_rsncipher = (enum mtk80211_cipher)that->fNextNodeToSend->ni_rsncipher;
    ni->rsn_akms = that->fNextNodeToSend->ni_rsnakms;
    ni->rsn_ciphers = that->fNextNodeToSend->ni_rsnciphers;
    ni->rsn_protos = that->fNextNodeToSend->ni_rsnprotos;
    ni->rsn_groupcipher = (enum mtk80211_cipher)that->fNextNodeToSend->ni_rsngroupcipher;
    ni->rsn_groupmgmtcipher = (enum mtk80211_cipher)that->fNextNodeToSend->ni_rsngroupmgmtcipher;
    ni->supported_rsnakms = that->fNextNodeToSend->ni_supported_rsnakms;
    ni->supported_rsnprotos = that->fNextNodeToSend->ni_supported_rsnprotos;
    ni->noise = 0;
    ni->rssi = -(0 - kMtkMinDbm - that->fNextNodeToSend->ni_rssi);
    memcpy(ni->bssid, that->fNextNodeToSend->ni_bssid, 6);
    memcpy(ni->ssid, that->fNextNodeToSend->ni_essid, 32);
    that->fNextNodeToSend = RB_NEXT(ieee80211_tree, &ic->ic_tree, that->fNextNodeToSend);
    if (that->fNextNodeToSend == NULL)
        that->fScanResultWrapping = true;
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sDEBUG(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    if (isSet) {
        struct ioctl_debug_set *req = (struct ioctl_debug_set *)data;
        return that->fDriverController->debugSet(req->op, req->val);
    }
    memset(data, 0, sizeof(struct ioctl_debug));
    that->fDriverController->fillDebug(data);
    return kIOReturnSuccess;
}

extern uint32_t mtk_log_read(uint64_t *cursor, char *out, uint32_t len, uint64_t *head_out);

IOReturn MtkWlanUserClient::
sLOG(OSObject* target, void* data, bool isSet)
{
    MtkWlanUserClient *that = OSDynamicCast(MtkWlanUserClient, target);
    struct ioctl_log *l = (struct ioctl_log *)data;
    if (isSet) {
        /* Rewind to the oldest byte still in the ring. */
        that->fLogCursor = 0;
        return kIOReturnSuccess;
    }
    memset(l, 0, sizeof(*l));
    l->version = IOCTL_VERSION;
    l->len = mtk_log_read(&that->fLogCursor, l->data, sizeof(l->data), &l->head);
    l->cursor = that->fLogCursor;
    return kIOReturnSuccess;
}

IOReturn MtkWlanUserClient::
sTX_POWER_LEVEL(OSObject* target, void* data, bool isSet)
{
    return kIOReturnSuccess;
}
