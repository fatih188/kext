//
//  _mbuf.cpp
//  SimpleMtkWlan
//
//  Created by laobamac (王孝慈) on 2026/4/21.
//  Copyright © 2026 laobamac (王孝慈). All rights reserved.
//

//
//  _mbuf.cpp
//  SimpleMtkWlan
//
//  Created by qcwap on 2020/6/14.
//  Copyright © 2020 钟先耀. All rights reserved.
//
/*
* Copyright (C) 2020  钟先耀
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

#include <sys/_mbuf.h>
extern "C" {
#include <net/bpf.h>
}
#include <IOKit/IOCommandGate.h>

extern IOCommandGate *_fCommandGate;

struct network_header {
    char pad[0x48];
};

static IOReturn _if_input(OSObject *target, void *arg0, void *arg1, void *arg2, void *arg3)
{
    mbuf_t m;
    bool isEmpty = true;
    struct _ifnet *ifq = (struct _ifnet *)arg0;
    struct mbuf_list *ml = (struct mbuf_list *)arg1;
    IOEthernetInterface *iface = ifq->iface;

    /* The interface can go away while frames are still queued (Wi-Fi off,
     * driver stop). Drop them instead of panicking. */
    if (iface == NULL) {
        ml_purge(ml);
        return kIOReturnNotReady;
    }

    /* Detach before transferring ownership. IOKit requires nextpkt == NULL,
     * and the driver must not walk a packet after inputPacket consumes it. */
    while ((m = ml_dequeue(ml)) != NULL) {
        isEmpty = false;
        iface->inputPacket(m, 0, IONetworkInterface::kInputOptionQueuePacket);
        if (ifq->netStat != NULL) {
            ifq->netStat->inputPackets++;
        }
    }
    if (!isEmpty) {
        iface->flushInputQueue();
    }
    return kIOReturnSuccess;
}

int if_input(struct _ifnet *ifq, struct mbuf_list *ml)
{
    return _fCommandGate->runAction((IOCommandGate::Action)_if_input, ifq, ml);
}

